package org.groupthirtytwo.game.players;

import static org.junit.Assert.*;

public class PlayerTest {
    Player player1 = new Player("player1",150,PlayerToken.BOOT,PlayerColour.BLUE);
    @org.junit.Test
    public void addProperty() {
    }

    @org.junit.Test
    public void remProperty() {
    }

    @org.junit.Test
    public void canWithdraw() {
    }

    @org.junit.Test
    public void withdraw() {
    }

    @org.junit.Test
    public void deposit() {
    }

    @org.junit.Test
    public void getProperties() {
    }
}