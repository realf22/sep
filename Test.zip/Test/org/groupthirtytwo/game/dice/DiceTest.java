package org.groupthirtytwo.game.dice;

import org.junit.Test;

import static org.junit.Assert.*;

public class DiceTest {

    @Test
    public void roll() {
    }
}