package org.groupthirtytwo.game.tiles;

import org.groupthirtytwo.game.players.Player;
import org.groupthirtytwo.game.players.PlayerToken;
import org.groupthirtytwo.game.tiles.configurations.TheOldCreek;
import org.junit.Test;

import static org.junit.Assert.*;

public class PropertyTest {


}