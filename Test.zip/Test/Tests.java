import org.groupthirtytwo.game.players.Player;
import org.groupthirtytwo.game.players.PlayerColour;
import org.groupthirtytwo.game.players.PlayerToken;
import org.groupthirtytwo.game.tiles.Property;
import org.groupthirtytwo.game.tiles.TileGroup;
import org.groupthirtytwo.game.tiles.configurations.TheOldCreek;
import org.junit.Test;

import static org.junit.Assert.*;


public class Tests {

    Player player1 = new Player("player1",150, PlayerToken.BOOT, PlayerColour.BLUE);
    Property oldcreek = new TheOldCreek();

    @Test
    public void addProperty () {
        assertEquals(0,player1.getProperties().size());
        player1.addProperty(oldcreek);
        assertEquals(1,player1.getProperties().size());
    }
    @Test
    public void deposit() {

        player1.deposit(150);
        assertEquals(300,player1.getBalance(),0.5);
    }
    @Test
    public void getProperties() {
        Property oldcreek2 = new TheOldCreek();
        player1.addProperty(oldcreek);
        assertTrue(player1.getProperties().contains(oldcreek));
        assertFalse(player1.getProperties().contains(oldcreek2));
    }
    @Test
    public void remProperty() {
        player1.addProperty(oldcreek);
        assertTrue(player1.getProperties().contains(oldcreek));
        player1.remProperty(oldcreek);
        assertFalse(player1.getProperties().contains(oldcreek));
    }
    @Test
    public void withdraw() {
        player1.withdraw(30);
        assertEquals(120,player1.getBalance(),0.5);
    }
    @Test
    public void getSymbol () {
        assertEquals(PlayerToken.BOOT,player1.getSymbol());
    }
    @Test
    public void hasProperty() {
        player1.hasProperty(oldcreek);
        assertTrue(player1.getProperties().contains(oldcreek));
    }
    @Test
    public void setOwner() {
        oldcreek.setOwner(player1);
        assertTrue(player1.getProperties().contains(oldcreek));
    }
    @Test
    public void getOwner() {
        player1.addProperty(oldcreek);
        assertEquals(player1,oldcreek.getOwner());
    }
    @Test
    public void getFine() {
        assertEquals(2d, oldcreek.getDefaultFine(),0.5);
    }
    @Test
    public void getGroup() {
        assertEquals(TileGroup.BROWN,oldcreek.getGroup());
    }

}
